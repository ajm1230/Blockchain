# 🚀 NodeVault Miner - Quick Setup (5 Minutes)

## ⚡ TL;DR - Get Running Fast

### Step 1: Update Server URL
Edit `miner/js/config.js` line 3:
```javascript
SERVER_URL: 'https://crypto3670.pythonanywhere.com',
WS_URL: 'wss://crypto3670.pythonanywhere.com'
```
Replace with YOUR PythonAnywhere username.

### Step 2: Open in Browser
```
file:///path/to/NodeVault/miner/index.html
```
OR upload to any web server.

### Step 3: Create Wallet
Click "Wallet" → "Create New" → Done!

### Step 4: Start Mining
Click "Mining" → "Start Mining" → Watch logs!

---

## 📁 File Structure (Copy This)

Your folder should look like:
```
NodeVault/
├── miner/
│   ├── index.html              ✅ Main page
│   ├── README.md               (Documentation)
│   ├── css/
│   │   ├── styles.css          ✅ Import file
│   │   └── theme.css           ✅ All styling
│   └── js/
│       ├── config.js           ✅ SERVER_URL here
│       ├── crypto.js           ✅ Signing & hashing
│       ├── storage.js          ✅ localStorage
│       ├── server.js           ✅ WebSocket & API
│       ├── blockchain.js       ✅ Chain validation
│       ├── mining.js           ✅ Proof-of-work
│       ├── mempool.js          ✅ Transaction pool
│       ├── wallet.js           ✅ Key management
│       ├── ui.js               ✅ UI updates
│       └── app.js              ✅ Main app
```

All files are ready to go!

---

## ⚙️ Configuration Required

**IMPORTANT:** Change this in `miner/js/config.js`:

```javascript
SERVER_URL: 'https://YOUR_USERNAME.pythonanywhere.com',
WS_URL: 'wss://YOUR_USERNAME.pythonanywhere.com'
```

Example for user `john123`:
```javascript
SERVER_URL: 'https://john123.pythonanywhere.com',
WS_URL: 'wss://john123.pythonanywhere.com'
```

---

## 🎮 Usage

### Create Wallet
1. Click **"Wallet"** tab
2. Click **"Create New"** button
3. Your address appears

### Start Mining
1. Click **"Mining"** tab
2. Click **"Start Mining"** button
3. Watch terminal logs
4. Blocks will be found!

### Send Transaction
1. Click **"Transactions"** tab
2. Enter recipient address
3. Enter amount + fee
4. Click **"Send"**
5. Appear in mempool, miners will pick it up

### View Blockchain
1. Click **"Blockchain"** tab
2. See all blocks with their hashes
3. Click a block to see details

---

## 🌐 Network Features

### Real-Time Updates
- WebSocket connects automatically
- Receive new transactions in real-time
- See other miners' blocks instantly
- Live node status

### Mining
- Selects high-fee transactions first
- Creates block with SHA-256 proof-of-work
- Broadcasts to all nodes
- Collects fees as reward

### Sync
- Validates your chain
- Compares with peers
- Auto-fixes if corrupted
- Longest chain rule

---

## 📊 Tabs Explained

| Tab | What It Does |
|-----|-----------|
| **Wallet** | Create/import, show balance, private key |
| **Mining** | Start/stop mining, see stats & logs |
| **Mempool** | View pending transactions in queue |
| **Blockchain** | View all blocks in chain |
| **My Blocks** | Blocks you personally mined |
| **Nodes** | Other miners connected to network |
| **Transactions** | Send BTC to other wallets |
| **Settings** | Configure server URL |
| **Logs** | System logs & debugging |

---

## 🔑 Keys & Security

### Private Key
- **Keep secret!** Don't share it
- Stored in browser localStorage
- Needed to sign transactions
- Never sent to server

### Public Key
- Safe to share
- Derived from private key
- Part of transaction signature

### Wallet Address
- Your public ID
- Where others send BTC to
- Derived from public key hash
- Safe to share

### Recovery
- Download recovery file before deleting wallet
- Contains your private key
- Can restore wallet anytime
- Keep it safe!

---

## 📈 Mining Explained

### How Mining Works
1. **Collect** high-fee transactions from mempool
2. **Bundle** them into a block
3. **Mine** by guessing nonce values
4. **Find** a hash starting with "000"
5. **Broadcast** block to network
6. **Earn** fees from included transactions

### Hash Rate
- Shows hashes per second (H/s)
- Faster computer = higher hash rate
- Depends on CPU, browser, background tasks

### Typical Times
- Laptop: **5-15 seconds per block**
- Phone: **30-60 seconds per block**
- Old PC: **1-3 minutes per block**

---

## 🔧 Troubleshooting

### "Mining doesn't start"
→ Check wallet is created first

### "No transactions in mempool"
→ Server offline? Check: `https://username.pythonanywhere.com/api/health`

### "WebSocket not connecting"
→ Check config has correct SERVER_URL

### "Balance shows 0"
→ No blocks mined yet. Keep mining or import existing wallet with balance

### "Can't find hash (000)"
→ Just keep mining, it's random. Will find eventually

### "Browser freezes while mining"
→ Normal on slow devices. Try less auto-mining

---

## 🎓 What You'll Learn

✅ How blockchain mining works  
✅ Cryptographic signatures (ECDSA)  
✅ SHA-256 hashing  
✅ Proof-of-work consensus  
✅ WebSocket real-time communication  
✅ Peer-to-peer networking  
✅ Transaction validation  
✅ Web Crypto API  

---

## 💡 Pro Tips

1. **Auto Mining** → Enable in Settings to mine continuously
2. **High Fees** → Miners pick high-fee transactions first
3. **Fast PC** → Use on powerful computer for better hash rate
4. **Multiple Wallets** → Import different private keys
5. **Monitor Fees** → Check mempool, see which fees miners prefer
6. **Keep Logs** → Download logs to analyze mining patterns

---

## 🚀 Next Steps

1. ✅ Update SERVER_URL in config.js
2. ✅ Open index.html in browser
3. ✅ Create wallet
4. ✅ Start mining
5. ✅ Send transactions
6. ✅ Watch blockchain grow

---

## 📱 Mobile?

Works on:
- ✅ iPhone Safari
- ✅ Android Chrome
- ✅ Tablets
- ✅ Any modern browser

Just open `index.html` on your phone!

Mining will be slower, but it works.

---

## 🆘 Getting Help

### Browser Console (`F12`)
Shows detailed logs:
- Server connection status
- Mining progress
- Transaction details
- Network events

### Logs Tab
Shows application logs with timestamps

### README.md
Full documentation with all details

---

## ⚠️ Important Notes

- **Private Key** never sent to server
- **Mining is CPU intensive** - may heat device
- **localStorage** depends on browser - clear cache = lose wallet (backup first!)
- **This is educational** - real Bitcoin has more features
- **No real money** - practice network only

---

## 🎉 You're Ready!

Everything is set up and ready to go. Just:

1. Change `SERVER_URL` in config.js
2. Open index.html
3. Click "Start Mining"
4. Watch your blockchain grow!

Questions? Check README.md or browser console for detailed logs.

Happy mining! ⛏️🚀

---

**Version:** 1.0.0  
**Network:** NodeVault Learning Blockchain  
**Made with:** HTML5 + Vanilla JS + Web Crypto API
