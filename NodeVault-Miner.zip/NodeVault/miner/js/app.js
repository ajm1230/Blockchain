/**
 * NodeVault Miner - Main Application
 * Initialize and manage all modules
 */

class MinerApp {
    constructor() {
        this.initialized = false;
    }

    async init() {
        console.log('[App] Initializing NodeVault Miner...');

        // Initialize modules
        Blockchain.load();
        Wallet.load();
        UI.init();
        Server.connect();

        // Setup event listeners
        this.setupEventListeners();

        // Update UI
        this.updateAllUI();

        // Setup auto-refresh
        setInterval(() => this.updateAllUI(), 5000);

        this.initialized = true;
        UI.addLog('NodeVault Miner started', 'success');
        console.log('[App] Initialization complete');
    }

    setupEventListeners() {
        // Wallet buttons
        document.getElementById('createWalletBtn')?.addEventListener('click', () => this.createWallet());
        document.getElementById('importWalletBtn')?.addEventListener('click', () => this.importWallet());
        document.getElementById('resetWalletBtn')?.addEventListener('click', () => this.resetWallet());
        document.getElementById('copyAddressBtn')?.addEventListener('click', () => this.copyToClipboard('walletAddress'));

        // Mining buttons
        document.getElementById('startMiningBtn')?.addEventListener('click', () => this.startMining());
        document.getElementById('stopMiningBtn')?.addEventListener('click', () => this.stopMining());
        document.getElementById('autoMiningToggle')?.addEventListener('change', (e) => this.toggleAutoMining(e.target.checked));

        // Mempool buttons
        document.getElementById('refreshMempoolBtn')?.addEventListener('click', () => this.refreshMempool());

        // Blockchain buttons
        document.getElementById('refreshNodesBtn')?.addEventListener('click', () => this.refreshNodes());

        // Transaction buttons
        document.getElementById('sendTransactionBtn')?.addEventListener('click', () => this.sendTransaction());

        // Settings buttons
        document.getElementById('saveServerSettingsBtn')?.addEventListener('click', () => this.saveSettings());
    }

    async createWallet() {
        UI.showToast('Creating wallet...');
        const result = await Wallet.create();
        document.getElementById('walletSetup').style.display = 'none';
        document.getElementById('walletInfo').style.display = 'block';
        document.getElementById('walletAddress').value = result.address;
        UI.showToast(CONFIG.MESSAGES.WALLET_CREATED, 'success');
        UI.addLog(`Wallet created: ${result.address}`, 'success');
        this.updateAllUI();
    }

    async importWallet() {
        const privKey = prompt('Paste your private key (JSON format):');
        if (!privKey) return;
        const success = await Wallet.import(privKey);
        if (success) {
            document.getElementById('walletSetup').style.display = 'none';
            document.getElementById('walletInfo').style.display = 'block';
            document.getElementById('walletAddress').value = Wallet.address;
            UI.showToast(CONFIG.MESSAGES.WALLET_IMPORTED, 'success');
            this.updateAllUI();
        } else {
            UI.showToast('Failed to import wallet', 'error');
        }
    }

    resetWallet() {
        if (confirm('Delete wallet from this device? (Download recovery file first!)')) {
            Storage.remove(CONFIG.STORAGE_KEYS.WALLET_PRIVATE_KEY);
            Storage.remove(CONFIG.STORAGE_KEYS.WALLET_PUBLIC_KEY);
            Storage.remove(CONFIG.STORAGE_KEYS.WALLET_ADDRESS);
            Wallet.privKeyJwk = null;
            document.getElementById('walletSetup').style.display = 'block';
            document.getElementById('walletInfo').style.display = 'none';
            UI.showToast('Wallet reset', 'success');
        }
    }

    async startMining() {
        if (!Wallet.address) {
            UI.showToast('Create wallet first', 'error');
            return;
        }
        UI.addLog('Starting mining...', 'success');
        document.getElementById('startMiningBtn').style.display = 'none';
        document.getElementById('stopMiningBtn').style.display = 'inline-flex';

        const txs = Mempool.selectHighFee(10);
        const block = await Mining.mineBlock(txs);

        if (block) {
            Blockchain.addBlock(block);
            await Server.broadcastBlock(block);
            UI.showToast(CONFIG.MESSAGES.BLOCK_FOUND, 'success');
            UI.addLog(`Block #${block.index} mined! Hash: ${block.hash}`, 'success');
            this.updateAllUI();
        }

        document.getElementById('startMiningBtn').style.display = 'inline-flex';
        document.getElementById('stopMiningBtn').style.display = 'none';
    }

    stopMining() {
        Mining.stop();
        document.getElementById('startMiningBtn').style.display = 'inline-flex';
        document.getElementById('stopMiningBtn').style.display = 'none';
        UI.showToast(CONFIG.MESSAGES.MINING_STOPPED);
    }

    toggleAutoMining(enabled) {
        console.log('[App] Auto mining:', enabled);
    }

    async refreshMempool() {
        try {
            const response = await Server.getMempoolTransactions();
            response.transactions?.forEach(tx => Mempool.addTransaction(tx));
            UI.updateMempoolTable(Mempool.getPending());
            UI.showToast('Mempool refreshed');
        } catch (e) {
            UI.showToast('Failed to refresh mempool', 'error');
        }
    }

    async refreshNodes() {
        try {
            const response = await Server.getOnlineNodes();
            UI.updateNodesTable(response.nodes || []);
            UI.showToast(`${response.nodes?.length || 0} nodes online`);
        } catch (e) {
            UI.showToast('Failed to refresh nodes', 'error');
        }
    }

    async sendTransaction() {
        const to = document.getElementById('recipientAddr')?.value;
        const amount = parseFloat(document.getElementById('txAmount')?.value);
        const fee = parseFloat(document.getElementById('txFee')?.value || 0.01);

        if (!to || !amount) {
            UI.showToast('Enter recipient and amount', 'error');
            return;
        }

        if (Wallet.getBalance() < amount + fee) {
            UI.showToast(CONFIG.MESSAGES.ERROR_INSUFFICIENT_BALANCE, 'error');
            return;
        }

        const tx = await Wallet.createTransaction(to, amount, fee);
        const response = await Server.broadcastTransaction(tx);

        if (response.success) {
            UI.showToast(CONFIG.MESSAGES.TRANSACTION_SENT, 'success');
            UI.addLog(`Transaction sent to ${to}`, 'success');
        } else {
            UI.showToast('Failed to send transaction', 'error');
        }
    }

    saveSettings() {
        const serverUrl = document.getElementById('serverUrl')?.value;
        if (serverUrl) {
            Storage.save('SERVER_URL', serverUrl);
            UI.showToast('Settings saved', 'success');
        }
    }

    copyToClipboard(elemId) {
        const elem = document.getElementById(elemId);
        if (elem) {
            navigator.clipboard.writeText(elem.value);
            UI.showToast('Copied to clipboard');
        }
    }

    updateAllUI() {
        UI.updateBalance(Wallet.getBalance());
        UI.updateStatus(Server.connected);
        UI.updateBlockchainTable(Blockchain.blocks);
        this.refreshMempool();
        this.refreshNodes();
    }
}

// Start app on page load
document.addEventListener('DOMContentLoaded', async () => {
    const app = new MinerApp();
    await app.init();
    window.app = app; // Global access for debugging
});
