/**
 * Crypto Module - Web Crypto API wrapper
 * Handles: key generation, signing, hashing
 */

const Crypto = {
    // Generate new keypair
    async generateKeyPair() {
        const keyPair = await window.crypto.subtle.generateKey(
            { name: 'ECDSA', namedCurve: 'P-256' },
            true,
            ['sign', 'verify']
        );
        const privKeyJwk = await window.crypto.subtle.exportKey('jwk', keyPair.privateKey);
        const pubKeyJwk = await window.crypto.subtle.exportKey('jwk', keyPair.publicKey);
        return { privKeyJwk, pubKeyJwk };
    },

    // Generate wallet address from public key
    async generateAddress(pubKeyJwk) {
        const encoder = new TextEncoder();
        const pubKeyStr = JSON.stringify(pubKeyJwk);
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', encoder.encode(pubKeyStr));
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return 'BC' + hashArray.map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 38);
    },

    // Sign transaction
    async signTransaction(transaction, privKeyJwk) {
        const privKey = await window.crypto.subtle.importKey('jwk', privKeyJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
        const encoder = new TextEncoder();
        const data = encoder.encode(JSON.stringify(transaction));
        const signature = await window.crypto.subtle.sign('ECDSA', privKey, data);
        return Array.from(new Uint8Array(signature)).map(b => b.toString(16).padStart(2, '0')).join('');
    },

    // Verify signature
    async verifySignature(transaction, signature, pubKeyJwk) {
        try {
            const pubKey = await window.crypto.subtle.importKey('jwk', pubKeyJwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
            const encoder = new TextEncoder();
            const data = encoder.encode(JSON.stringify(transaction));
            const sigBuffer = new Uint8Array(signature.match(/../g).map(b => parseInt(b, 16)));
            return await window.crypto.subtle.verify('ECDSA', pubKey, sigBuffer, data);
        } catch (e) {
            return false;
        }
    },

    // Calculate SHA-256 hash
    async sha256(data) {
        const encoder = new TextEncoder();
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', encoder.encode(JSON.stringify(data)));
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
};
