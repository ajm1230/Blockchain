const Mining = {
    isMining: false,
    startTime: 0,
    attempts: 0,
    blocksMined: 0,

    async mineBlock(transactions) {
        this.isMining = true;
        this.startTime = Date.now();
        this.attempts = 0;

        const block = {
            index: Blockchain.blocks.length,
            previousHash: Blockchain.blocks.length > 0 ? Blockchain.blocks[Blockchain.blocks.length - 1].hash : '0000',
            transactions,
            timestamp: new Date().toISOString(),
            nonce: 0,
            hash: ''
        };

        while (this.isMining) {
            block.nonce++;
            this.attempts++;
            block.hash = await Crypto.sha256(block);

            if (block.hash.startsWith(CONFIG.DIFFICULTY)) {
                this.blocksMined++;
                return block;
            }

            if (this.attempts % 1000 === 0) {
                await new Promise(r => setTimeout(r, 0)); // Yield to browser
            }
        }
        return null;
    },

    stop() {
        this.isMining = false;
    },

    getHashRate() {
        const elapsed = (Date.now() - this.startTime) / 1000 || 1;
        return (this.attempts / elapsed).toFixed(2);
    }
};
