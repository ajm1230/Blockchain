const Wallet = {
    privKeyJwk: null,
    pubKeyJwk: null,
    address: null,

    async create() {
        const { privKeyJwk, pubKeyJwk } = await Crypto.generateKeyPair();
        const address = await Crypto.generateAddress(pubKeyJwk);
        this.privKeyJwk = privKeyJwk;
        this.pubKeyJwk = pubKeyJwk;
        this.address = address;
        Storage.save(CONFIG.STORAGE_KEYS.WALLET_PRIVATE_KEY, privKeyJwk);
        Storage.save(CONFIG.STORAGE_KEYS.WALLET_PUBLIC_KEY, pubKeyJwk);
        Storage.save(CONFIG.STORAGE_KEYS.WALLET_ADDRESS, address);
        return { address, privKey: JSON.stringify(privKeyJwk) };
    },

    async import(privKeyJson) {
        try {
            const privKeyJwk = JSON.parse(privKeyJson);
            const pubKeyJwk = privKeyJwk; // Simplified
            const address = await Crypto.generateAddress(pubKeyJwk);
            this.privKeyJwk = privKeyJwk;
            this.pubKeyJwk = pubKeyJwk;
            this.address = address;
            Storage.save(CONFIG.STORAGE_KEYS.WALLET_PRIVATE_KEY, privKeyJwk);
            Storage.save(CONFIG.STORAGE_KEYS.WALLET_PUBLIC_KEY, pubKeyJwk);
            Storage.save(CONFIG.STORAGE_KEYS.WALLET_ADDRESS, address);
            return true;
        } catch (e) {
            return false;
        }
    },

    load() {
        this.privKeyJwk = Storage.get(CONFIG.STORAGE_KEYS.WALLET_PRIVATE_KEY);
        this.pubKeyJwk = Storage.get(CONFIG.STORAGE_KEYS.WALLET_PUBLIC_KEY);
        this.address = Storage.get(CONFIG.STORAGE_KEYS.WALLET_ADDRESS);
        return this.address !== null;
    },

    getBalance() {
        return this.address ? Blockchain.getBalance(this.address) : 0;
    },

    async createTransaction(to, amount, fee = 0.01) {
        if (!this.address) return null;
        const tx = {
            from: this.address,
            to,
            amount,
            fee,
            timestamp: new Date().toISOString(),
            publicKey: this.pubKeyJwk
        };
        tx.signature = await Crypto.signTransaction(tx, this.privKeyJwk);
        return tx;
    }
};
