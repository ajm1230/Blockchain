const Blockchain = {
    blocks: [],

    load: function() {
        this.blocks = Storage.get(CONFIG.STORAGE_KEYS.BLOCKCHAIN) || [];
    },

    save: function() {
        Storage.save(CONFIG.STORAGE_KEYS.BLOCKCHAIN, this.blocks);
    },

    addBlock: function(block) {
        if (this.validateBlock(block)) {
            this.blocks.push(block);
            this.save();
            return true;
        }
        return false;
    },

    validateBlock: function(block) {
        if (!block.hash || !block.hash.startsWith(CONFIG.DIFFICULTY)) return false;
        if (this.blocks.length > 0 && block.previousHash !== this.blocks[this.blocks.length - 1].hash) return false;
        return true;
    },

    getBalance: function(address) {
        let balance = 0;
        for (const block of this.blocks) {
            for (const tx of block.transactions) {
                if (tx.from === address) balance -= tx.amount + (tx.fee || 0);
                if (tx.to === address) balance += tx.amount;
            }
        }
        return balance;
    },

    getChainLength: function() {
        return this.blocks.length;
    },

    validate: function() {
        for (let i = 1; i < this.blocks.length; i++) {
            if (!this.validateBlock(this.blocks[i])) return false;
            if (this.blocks[i].previousHash !== this.blocks[i - 1].hash) return false;
        }
        return true;
    }
};
