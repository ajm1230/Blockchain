const Mempool = {
    transactions: [],

    addTransaction: function(tx) {
        if (!this.transactions.find(t => t.txId === tx.txId)) {
            this.transactions.push(tx);
            return true;
        }
        return false;
    },

    getPending: function() {
        return this.transactions;
    },

    selectHighFee: function(count = 10) {
        return this.transactions.sort((a, b) => (b.fee || 0) - (a.fee || 0)).slice(0, count);
    },

    remove: function(tx) {
        this.transactions = this.transactions.filter(t => t.txId !== tx.txId);
    },

    clear: function() {
        this.transactions = [];
    }
};
