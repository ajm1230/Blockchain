const UI = {
    currentTab: 'wallet',

    init() {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.closest('.nav-btn').dataset.tab));
        });
    },

    switchTab(tabName) {
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`${tabName}Tab`).classList.add('active');
        this.currentTab = tabName;
    },

    updateBalance(amount) {
        const elem = document.getElementById('balanceAmount');
        if (elem) elem.textContent = amount.toFixed(2);
    },

    updateStatus(online) {
        const ind = document.getElementById('statusIndicator');
        const txt = document.getElementById('statusText');
        if (ind) {
            ind.classList.toggle('online', online);
            ind.classList.toggle('offline', !online);
        }
        if (txt) txt.textContent = online ? 'Online' : 'Offline';
    },

    updateMempoolTable(transactions) {
        const tbody = document.getElementById('mempoolBody');
        if (!tbody) return;
        if (transactions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5">No pending transactions</td></tr>';
            return;
        }
        tbody.innerHTML = transactions.map(tx => `
            <tr>
                <td>${tx.txId?.slice(0, 8) || 'N/A'}</td>
                <td>${tx.from?.slice(0, 8) || 'N/A'}</td>
                <td>${tx.to?.slice(0, 8) || 'N/A'}</td>
                <td>${tx.amount || 0}</td>
                <td>${tx.fee || 0}</td>
            </tr>
        `).join('');
    },

    updateBlockchainTable(blocks) {
        const tbody = document.getElementById('blockchainBody');
        if (!tbody) return;
        tbody.innerHTML = blocks.map((b, i) => `
            <tr>
                <td>#${b.index || i}</td>
                <td>${b.hash?.slice(0, 8) || 'N/A'}</td>
                <td>${b.transactions?.length || 0}</td>
                <td>${new Date(b.timestamp).toLocaleDateString() || 'N/A'}</td>
            </tr>
        `).join('');
        document.getElementById('totalBlocks').textContent = blocks.length;
        document.getElementById('chainLength').textContent = blocks.length;
    },

    updateNodesTable(nodes) {
        const tbody = document.getElementById('nodesBody');
        if (!tbody) return;
        if (nodes.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4">No nodes connected</td></tr>';
            return;
        }
        tbody.innerHTML = nodes.map(n => `
            <tr>
                <td>${n.nodeId?.slice(0, 8) || 'N/A'}</td>
                <td>${n.walletAddress?.slice(0, 8) || 'N/A'}</td>
                <td>${n.chainLength || 0}</td>
                <td><span class="badge">${n.status || 'unknown'}</span></td>
            </tr>
        `).join('');
    },

    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = message;
        toast.className = `toast show ${type}`;
        setTimeout(() => toast.classList.remove('show'), CONFIG.TOAST_DURATION);
    },

    addLog(message, type = 'info') {
        const log = document.getElementById('miningLog') || document.getElementById('systemLogs');
        if (!log) return;
        const line = document.createElement('div');
        line.className = `log-line ${type}`;
        line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
        while (log.children.length > CONFIG.TERMINAL_MAX_LINES) {
            log.removeChild(log.firstChild);
        }
    }
};
