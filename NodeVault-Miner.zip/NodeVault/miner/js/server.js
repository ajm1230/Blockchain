const Server = {
    socket: null,
    connected: false,

    connect: function() {
        this.socket = io(CONFIG.SERVER_URL);
        this.socket.on('connect', () => { this.connected = true; console.log('[Server] Connected'); });
        this.socket.on('disconnect', () => { this.connected = false; console.log('[Server] Disconnected'); });
        this.socket.on('transaction_broadcast', (data) => console.log('[Server] New tx:', data.txId));
        this.socket.on('block_broadcast', (data) => console.log('[Server] New block:', data.blockId));
    },

    async broadcastTransaction: function(tx) {
        return fetch(`${CONFIG.SERVER_URL}/api/transactions/broadcast`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tx)
        }).then(r => r.json());
    },

    async broadcastBlock: function(block) {
        return fetch(`${CONFIG.SERVER_URL}/api/blocks/broadcast`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(block)
        }).then(r => r.json());
    },

    async getMempoolTransactions: function() {
        return fetch(`${CONFIG.SERVER_URL}/api/transactions/pending`).then(r => r.json());
    },

    async getOnlineNodes: function() {
        return fetch(`${CONFIG.SERVER_URL}/api/nodes/list`).then(r => r.json());
    },

    async registerNode: function(nodeData) {
        return fetch(`${CONFIG.SERVER_URL}/api/nodes/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nodeData)
        }).then(r => r.json());
    }
};
