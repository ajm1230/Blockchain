/**
 * NodeVault Miner - Configuration
 * Central configuration for server URL, difficulty, and constants
 */

const CONFIG = {
    // Server Configuration
    SERVER_URL: 'https://crypto3670.pythonanywhere.com',
    WS_URL: 'wss://crypto3670.pythonanywhere.com',
    API_TIMEOUT: 10000,

    // Mining Configuration
    DIFFICULTY: '000',  // Target: hash starts with "000"
    BLOCK_REWARD: 50,   // Initial reward
    HALVING_INTERVAL: 210000,

    // UI
    HASH_UPDATE_INTERVAL: 1000,  // Update stats every 1 sec
    TERMINAL_MAX_LINES: 100,
    TOAST_DURATION: 3000,

    // Storage Keys
    STORAGE_KEYS: {
        WALLET_PRIVATE_KEY: 'wallet_private_key',
        WALLET_PUBLIC_KEY: 'wallet_public_key',
        WALLET_ADDRESS: 'wallet_address',
        BLOCKCHAIN: 'blockchain_blocks',
        MINING_STATS: 'mining_stats',
        NODE_ID: 'node_id',
        SETTINGS: 'miner_settings'
    },

    // Messages
    MESSAGES: {
        WALLET_CREATED: '✅ Wallet created successfully',
        WALLET_IMPORTED: '✅ Wallet imported successfully',
        MINING_STARTED: '⛏️ Mining started',
        MINING_STOPPED: '⏹️ Mining stopped',
        BLOCK_FOUND: '🎉 Block found!',
        TRANSACTION_SENT: '💸 Transaction sent',
        ERROR_INVALID_ADDRESS: '❌ Invalid wallet address',
        ERROR_INSUFFICIENT_BALANCE: '❌ Insufficient balance',
        ERROR_SERVER_OFFLINE: '❌ Server offline',
        CONNECTED: '🟢 Connected to network',
        DISCONNECTED: '🔴 Disconnected from network'
    }
};

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
