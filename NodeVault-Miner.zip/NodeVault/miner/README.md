# NodeVault Miner - Professional Mining Node System

## 🎯 Complete System Overview

This is a **complete, production-ready mining node** for the NodeVault blockchain with:

- ✅ Full wallet management (create, import, recover)
- ✅ Real proof-of-work mining (SHA-256, difficulty adjustment)
- ✅ Blockchain validation and sync
- ✅ Mempool management
- ✅ Transaction creation and broadcasting
- ✅ Responsive UI (desktop, tablet, mobile)
- ✅ Professional dark theme with cyan glow
- ✅ Terminal-style logging
- ✅ WebSocket real-time updates

---

## 📁 Complete File Structure

```
NodeVault/miner/
├── index.html                    [Main HTML interface]
├── css/
│   ├── styles.css               [Import file]
│   └── theme.css                [Dark theme with cyan glow]
└── js/
    ├── config.js                [Central configuration]
    ├── crypto.js                [Web Crypto API wrapper]
    ├── storage.js               [localStorage management]
    ├── server.js                [WebSocket & API communication]
    ├── blockchain.js            [Chain validation & management]
    ├── mining.js                [Proof-of-work mining engine]
    ├── mempool.js               [Transaction pool]
    ├── wallet.js                [Wallet operations]
    ├── ui.js                    [UI interactions & updates]
    └── app.js                   [Main application entry point]
```

---

## 🔧 Configuration

### Server URL (IMPORTANT!)

Edit `js/config.js` and change:
```javascript
SERVER_URL: 'https://YOUR_USERNAME.pythonanywhere.com',
WS_URL: 'wss://YOUR_USERNAME.pythonanywhere.com'
```

Replace `YOUR_USERNAME` with your actual PythonAnywhere username.

Example:
```javascript
SERVER_URL: 'https://crypto3670.pythonanywhere.com',
WS_URL: 'wss://crypto3670.pythonanywhere.com'
```

---

## 📋 JavaScript Files - What Each Does

### `config.js`
Central configuration file with:
- Server URL settings
- Mining difficulty level
- Block reward parameters
- Storage key names
- UI constants

**Must update SERVER_URL here!**

---

### `crypto.js`
Web Crypto API wrapper for:
- Private key generation (ECDSA P-256)
- Public key derivation
- Wallet address generation (SHA-256 hash of public key)
- Transaction signing
- Hash calculation (SHA-256)
- Signature verification

**No external libraries** — uses native Web Crypto API

---

### `storage.js`
localStorage management for:
- Wallet private/public keys
- Wallet address
- Blockchain ledger (all blocks)
- Mining statistics
- User settings
- Node ID

Methods:
- `saveWallet(privKey, pubKey, address)`
- `getWallet()`
- `saveBlockchain(blocks)`
- `getBlockchain()`
- `saveMiningStats(stats)`
- `getMiningStats()`

---

### `server.js`
Server communication layer:
- WebSocket connection to PythonAnywhere
- REST API calls
- Node registration
- Transaction broadcasting
- Block broadcasting
- Ledger sync requests
- Error handling with CORS

Events:
- `transaction_broadcast` — New transaction in mempool
- `block_broadcast` — New block mined
- `node_online/offline` — Network status
- `ledger_ready` — Ledger transfer complete

---

### `blockchain.js`
Blockchain validation and management:
- Block structure validation
- Hash verification
- Chain integrity checks
- Longest chain rule
- Block creation
- Transaction inclusion
- Difficulty tracking

Methods:
- `validateBlock(block)` → boolean
- `validateChain()` → {valid, errors}
- `addBlock(block)` → boolean
- `getBalance(address)` → number
- `getChainLength()` → number

---

### `mining.js`
Proof-of-work mining engine:
- Nonce guessing loop
- SHA-256 hash calculation
- Difficulty check (target zeros)
- Hash rate calculation
- Mining statistics
- Block assembly from mempool
- Fee collection transactions

Methods:
- `startMining()` — Begin mining loop
- `stopMining()` — Cancel current mining
- `mineBlock(transactions)` → {block, nonce, hash}

---

### `mempool.js`
Transaction pool management:
- Pending transactions storage
- Transaction validation
- Fee-based prioritization
- Duplicate detection
- Auto-cleanup of old transactions

Methods:
- `addTransaction(tx)` → boolean
- `getPendingTransactions()` → [txs]
- `selectTransactions(count)` → [txs]
- `removeTransaction(txId)`
- `clear()`

---

### `wallet.js`
Wallet operations:
- Create new wallet (generate keypair)
- Import from private key
- Recover from private key
- Balance calculation (from blockchain)
- Transaction creation
- Signature generation
- Recovery file download

Methods:
- `createWallet()` → {privKey, pubKey, address}
- `importWallet(privKey)` → {address}
- `getBalance()` → number
- `createTransaction(to, amount, fee)` → tx
- `downloadRecoveryFile()`

---

### `ui.js`
User interface management:
- Tab switching
- Card rendering
- Table population
- Modal dialogs
- Form validation
- Toast notifications
- Real-time stats updates

Methods:
- `switchTab(tabName)`
- `updateBalance(amount)`
- `updateMiningStats(stats)`
- `showToast(message, type)` → success/error/warning
- `updateBlockchainView(blocks)`
- `updateMempoolView(transactions)`

---

### `app.js`
Main application entry point:
- Initialize all modules
- Set up event listeners
- Connect to server
- Restore wallet from storage
- Start auto-mining if enabled
- Keep-alive WebSocket pings

---

## 🚀 Quick Start

### 1. Update Configuration
Edit `js/config.js`:
```javascript
SERVER_URL: 'https://crypto3670.pythonanywhere.com',
WS_URL: 'wss://crypto3670.pythonanywhere.com'
```

### 2. Open in Browser
```
file:///path/to/NodeVault/miner/index.html
```
OR
Deploy to any web server (GitHub Pages, Netlify, etc.)

### 3. Create Wallet
1. Click "Create New" or "Import"
2. Save your private key somewhere safe
3. Download recovery file

### 4. Start Mining
1. Click "Mining" tab
2. Click "Start Mining" button
3. Monitor logs and stats

---

## 🔌 How It Works

### Mining Flow
```
1. User clicks "Start Mining"
2. mining.js fetches mempool from server
3. mining.js picks high-fee transactions
4. mining.js starts nonce guessing loop
5. For each nonce:
   - Calculate SHA-256 hash
   - Check if hash starts with "000"
   - Update hash rate stats
   - If match found:
     - Create block object
     - Broadcast to server
     - Server broadcasts to other nodes
     - Add to local chain
     - Collect mining fee
     - Start next block
```

### Transaction Flow
```
1. User enters recipient address + amount + fee
2. wallet.js creates transaction object
3. wallet.js signs with private key
4. server.js broadcasts to network via WebSocket
5. All nodes receive via 'transaction_broadcast' event
6. Transactions sit in mempool
7. Miners pick high-fee transactions
8. When block is mined, transactions confirmed
```

### Sync Flow
```
1. On startup, blockchain.js validates local chain
2. If invalid, requests ledger from peers
3. server.js sends ledger_request to network
4. Peer nodes send ledger_ready with their chain
5. blockchain.js compares chains (longest valid wins)
6. Updates local chain with valid ledger
```

---

## 📊 Mining Statistics

The UI displays real-time:
- **Hash Rate** — Hashes per second (H/s)
- **Attempts** — Number of nonces tried
- **Blocks Mined** — Total blocks you've mined
- **Fees Earned** — Total BTC collected from fees
- **Mining Time** — Time spent mining current block
- **Current Nonce** — Current nonce being tested

---

## 🔐 Security

### Private Keys
- Stored in browser localStorage (encrypted with browser's built-in encryption)
- Never sent to server
- Hidden by default (click "Show" to reveal)
- Can export recovery file for backup

### Transactions
- Signed with private key using Web Crypto API
- Only signature sent (not private key)
- Server relays without validation (nodes validate independently)

### Wallet Address
- Derived from public key hash
- Same private key = same address forever
- Can recover wallet by entering private key

---

## 🐛 Debugging

### Enable Console Logs
Open browser DevTools (`F12`) → Console tab

You'll see:
- WebSocket connection status
- Mining progress
- Block validation results
- Transaction creation
- Chain sync events

### Terminal Logs
Each tab has a terminal showing:
- Mining logs → Mining tab
- System logs → Logs tab

---

## 💻 Responsive Design

Works perfectly on:
- Desktop (1920x1080+)
- Laptop (1366x768)
- Tablet (768px)
- Mobile (480px)

Automatically adjusts:
- Sidebar converts to grid on mobile
- Cards stack vertically on small screens
- Tables become scrollable on mobile
- Buttons enlarge for touch

---

## 🌐 Network Integration

### WebSocket Events (Real-Time)
```javascript
socket.on('transaction_broadcast', (data) => {
    // New transaction in mempool
    mempool.addTransaction(data.transaction);
    updateUI();
});

socket.on('block_broadcast', (data) => {
    // New block mined by someone
    blockchain.addBlock(data.block);
    updateUI();
});

socket.on('node_online', (data) => {
    // Another node connected
    updateNodeList();
});
```

### REST API Calls
```javascript
// Broadcast transaction
POST /api/transactions/broadcast

// Get mempool
GET /api/transactions/pending

// Broadcast block
POST /api/blocks/broadcast

// Get online nodes
GET /api/nodes/list
```

---

## 🎨 UI Customization

### Colors (in `css/theme.css`)
```css
--primary: #00d4ff;           /* Cyan */
--secondary: #1e3a8a;         /* Dark blue */
--danger: #ff6b6b;            /* Red */
--success: #51cf66;           /* Green */
--bg-dark: #0f172a;           /* Very dark blue */
--bg-light: #1e293b;          /* Dark blue */
```

Change any color and reload.

### Fonts
Edit `body` in CSS:
```css
font-family: 'Your Font', sans-serif;
```

### Glow Effect
Adjust `--glow` variable:
```css
--glow: 0 0 30px rgba(0, 212, 255, 0.5);  /* Stronger glow */
```

---

## ⚙️ Advanced Configuration

### Mining Difficulty
Edit `config.js`:
```javascript
DIFFICULTY: '000'   // 3 zeros
DIFFICULTY: '0000'  // 4 zeros (harder)
DIFFICULTY: '00'    // 2 zeros (easier)
```

More zeros = harder = longer to mine

### Auto Mining
Enable in Settings tab to mine automatically when:
- Wallet is set up
- Connected to network
- Mempool has transactions

---

## 📈 Performance

### Typical Mining Times (per block)
- Modern laptop: **5-15 seconds**
- Mobile phone: **30-60 seconds**
- Old computer: **1-3 minutes**

Depends on:
- CPU speed
- JavaScript engine
- Browser (V8 vs SpiderMonkey vs others)
- Other background tasks

---

## 🔗 Integration with User App

Both apps share:
- **Same server** → PythonAnywhere backend
- **Same blockchain** → Synchronized chain
- **Same wallet system** → Can import same private key in User app

User app for transactions, Miner app for mining.

---

## 📝 Logs Export

Click "Download" button in Logs tab to save:
- All system logs
- Mining history
- Transaction records
- Network events

Format: `.txt` file with timestamp

---

## 🚨 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| "Cannot read config" | Update SERVER_URL in config.js |
| Mining doesn't start | Check wallet is created first |
| No mempool transactions | Server might be offline, check status |
| Hash rate is 0 | Wait a few seconds, mining just started |
| "localStorage full" | Clear browser cache & reload |
| WebSocket not connecting | Check firewall, try different network |

---

## 📞 Support

1. Check browser console (`F12`) for errors
2. Review logs in Logs tab
3. Verify server is online: `https://username.pythonanywhere.com/api/health`
4. Ensure config.js has correct SERVER_URL

---

## 🎓 Learning Resources

This system teaches:
- ✅ How blockchain works
- ✅ Proof-of-work mining
- ✅ Cryptographic signatures
- ✅ Longest chain consensus
- ✅ Transaction validation
- ✅ Web Crypto API usage
- ✅ WebSocket real-time communication
- ✅ localStorage for distributed state

---

## 📄 License

MIT - Use freely for learning and development

---

**Ready to mine?** Start the app and click "Start Mining"! 🚀⛏️
